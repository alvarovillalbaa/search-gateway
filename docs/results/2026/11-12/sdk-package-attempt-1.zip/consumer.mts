import {SearchGateway,createSearchTool,type SearchRequest} from '@alvarovillalbaa/search-gateway';
import {createSearchGateway} from '@alvarovillalbaa/search-gateway/core';
import {createGatewayServer} from '@alvarovillalbaa/search-gateway/server';
import {useSearchGateway} from '@alvarovillalbaa/search-gateway/react';
const request:SearchRequest={query:'authored'};
const client=new SearchGateway({baseUrl:'http://127.0.0.1:8787'});
const hook=()=>useSearchGateway(client); const tool=createSearchTool(client);
void [request,hook,tool,createSearchGateway,createGatewayServer];
